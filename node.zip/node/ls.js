const fs = require('fs')
const os = require('os')

let dir = process.argv.length > 2 ? process.argv[2] : null;
console.log("Your path:" + dir);
if(dir != null){
  if(fs.existsSync(dir)){
    fs.readdir(process.argv[2], (err, files) => {
      files.forEach(file => {
        console.log(file);
      });
    });
  }else{
    console.log('Invalid path');  
  }
}else{
  console.log("Provide a path");
}


/*process.argv.forEach((val, index) => {
  console.log(`${index}: ${val}`);
});
*/

