const timeoutObj = setTimeout (()=> {
  console.log('timeout beyond time');
}, 1500);

const immediateObj = setImmediate(() => {
 console.log('inmmediately executing immediate');
});

const intervalObj = setInterval(() => {
  console.log('interviewing the interval');
}, 500);

clearTimeout(timeoutObj);
clearImmediate(immediateObj);
clearInterval(intervalObj);

console.log('algo');
