var myModule1=require('mypackage');
var myModule2=require('mypackage');

console.log('mod1:' + myModule1.myDateTime());

function print(){
  console.log('mod2:' + myModule2.myDateTime());
}
setTimeout(print, 2000);
