var fss = require('fs');
fss.rename('test', 'renamed', function(err){
  if(err){
    throw err;
  }
  console.log('File renamed');
});

const fs = require('fs');

fs.unlink('renamed',(err)=> {
  if(err){
    throw err;
  }
  console.log('File removed');
});
