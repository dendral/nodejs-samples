const express=require('express')
const bodyParser=require('body-parser')
const request=require('request')

const app = express()

app.use(bodyParser.json())

app.get('/greetings', (req, res) =>{
  var usuario = req.query.nombre;
  console.log('Se recibe: ' + usuario);
  
  request.post("http://name_service:3001/echo", {json:{"nombre":usuario}}, (err, r, body)=>{
    if (err) {
      console.error(err);
      res.sendStatus(500);
      return
    }
    console.log('respuesta from echo:' + body);
    res.send("Hello " + body);
  });


  //res.send('JSON received: ' + JSON.stringify(req.body));
});


/*
setTimeout(function(){
  request.post("http://my_custom_app:3000", { json: { key: 'value' } }, (err, res, body)=>{
    if (err) {
      console.error(err)
      return
    }
    console.log(body);
  });
}, 10000);
*/
app.listen(3000, function(){
  console.log('Express started...');
});


