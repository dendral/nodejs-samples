var fs= require('fs');

fs.readFile('i/etc/passwd', function(err, file){
  if(err){
    throw err;
  }
  console.log('file content:', file.toString());
});
