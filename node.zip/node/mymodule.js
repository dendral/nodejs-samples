console.log('loading my module...');

exports.myDateTime =function (){
  return Date();
};

console.log('my module initialized...');
