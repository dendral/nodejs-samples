var Circle = require('./circle.js');
var circle = new Circle(10,20,3);
console.log(circle);
console.log(circle.area);
console.log(circle.area());
console.log(circle.r());
