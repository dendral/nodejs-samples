const express=require('express')
const bodyParser=require('body-parser')

const app = express()
app.use(bodyParser.json())

app.post('/echo', (req, res) =>{
  var usuario = req.body.nombre;
  console.log('Se recibe: ' + usuario);
  res.send(usuario);
});


app.listen(3001, function(){
  console.log('Express 3001 started...');
});


