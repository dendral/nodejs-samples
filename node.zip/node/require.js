const fs = require('fs')
const os = require('os')

fs.readdir(os.homedir(), (err, files) => {
  files.forEach(file => {
    console.log(file);
  });
});
