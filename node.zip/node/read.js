var readLine=require('readline')

var rl = readLine.createInterface({
  input: process.stdin,
  output: process.stdout
});

rl.question("What do you think of node?",
  function(answer){
    console.log("Thank you for your valuable feedback:", answer);
    rl.close();
 });
