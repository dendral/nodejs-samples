/*
console.log(__dirname);
console.log(__filename);
//console.log('hello world!');

process.on('beforeExit', (code)=>{
  console.log('Process beforeExit event with code: ', code);
});

process.on('exit', (code)=>{
  console.log('Process exit event with code: ', code);
});

console.log('This message is dsplayed first.');

function myFunction(arg){
  console.log(`arg was => ${arg}`);
}

setTimeout(myFunction, 1500, 'Hello Node.js');
*/
console.log('before inmediate');
setImmediate((arg) => {
 console.log(`executing immediate: ${arg}`);
}, 'so inmediate');

console.log('after immediate');
console.log('after immediate');
console.log('after immediate');
console.log('after immediate');
