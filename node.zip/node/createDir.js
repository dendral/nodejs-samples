var fs=require('fs');
var dir='/tmp/mydir';

if(!fs.existsSync(dir)){
 fs.mkdirSync(dir);
}
