const winston = require('winston');
const express = require('express');
const app = express();
const port = 3000;

const logger = winston.createLogger({
  transports: [
    new winston.transports.Console()
  ]
});

const handler = (func) => (req, res) => {
  try{
     logger.info('server.handler.begun');
     func(req, res, logger);
  }catch(e){
    logger.info('server.handler.failed');
    res.send('Something went wrong');
  }
};

app.get('/success', handler((req, res, log) => {
  log.info("All ok");
  res.send('Yay!');
}));

app.get('/error', handler((req, res) => {
  throw new Error('Doh');
}));

app.listen(port, ()=>console.log(`Example app listening port ${port}`));

