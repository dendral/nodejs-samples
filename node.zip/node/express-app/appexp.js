var express = require('express');
var app = express();


app.get('/:algo/done', function(req, res){
  console.log(req.query);
  console.log(req.headers);
  console.log(req.params);
  console.log("GET request homepage");
  res.send('Get request homepage');
});

app.post('/', function(req, res){
  console.log("POST request homepage");
  res.send('Post request homepage');
});

app.delete('/', function(req, res){
  console.log("DELETE request homepage");
  res.send('Delete request homepage');
});


app.get('/list', function(req, res){
  console.log("GET request /list");
  res.send('Get request /list');
});

app.get('/ab*cd', function(req, res){
  console.log("GET request /ab*cd");
  res.send('Get request /ab*cd');
});

app.listen(3000, ()=>{
  console.log("server started...");
});
