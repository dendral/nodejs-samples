const winston = require('winston');
const logger = winston.createLogger({
  transports: [
    new winston.transports.Console()
  ]
});

logger.info('What rolls down the stairs');
logger.warn('waaarn');
logger.error('error');


