var express = require('express');
var app = express();
const fs = require('fs');

app.post('/file', function(req, res){
  console.log(req.query);
  console.log(req.params);
  let filename = req.query.filename;
  let content = req.query.content;
  let pathplusfile = "/home/admin/archivos/"+filename;
  
  fs.writeFile(pathplusfile, content, function(err){
    if(err){
      console.log(console.log(err));
      return console.log(err);
    }
    console.log("File test saved");
  });
  
  res.send('File ' + filename + ' created');
});

app.put('/file/:archivo', function(req, res){
  console.log(req.query);
  console.log(req.params);
  let filename = req.params.archivo;
  let content = req.query.content;
  let pathplusfile = "/home/admin/archivos/"+filename;
console.log(pathplusfile);
  fs.appendFile(pathplusfile, content, function(err){
    if(err){
      console.log(console.log(err));
      return console.log(err);
    }
    console.log("File " + filename + ' updated');
  });

  res.send('File ' + filename + ' updated');
});

app.put('/rename/:archivo', function(req, res){
  console.log(req.query);
  console.log(req.params);
  let filename = req.params.archivo;
  let newname = req.query.newname;
  let oldfile = "/home/admin/archivos/"+filename;
  let newfile = "/home/admin/archivos/"+newname;

  fs.rename(oldfile, newfile, function(err){
    if(err){
      console.log(console.log(err));
      return console.log(err);
    }
    console.log("old " + oldfile + ' new ' + newfile);
  });

  res.send('Renamed to ' + newfile);
});


app.get('/file/:archivo', function(req, res){
  console.log(req.query);
  console.log(req.params);
  let filename = req.params.archivo;
  let pathplusfile = "/home/admin/archivos/"+filename;

fs.readFile(pathplusfile, function(err, file){
  if(err){
    throw err;
  }
  res.send('File->' + file.toString());
});
  

});



app.listen(3000, ()=>{
  console.log("server started...");
});
