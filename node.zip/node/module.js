var http = require('http')
console.log('before require');
var dt = require('./mymodule');
console.log('after require');
console.log(dt.myDateTime());

function print(){
  console.log(dt.myDateTime());
}

setTimeout(print, 2000);
