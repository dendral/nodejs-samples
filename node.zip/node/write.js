const fs = require('fs');

fs.writeFile("test", "Hello world", function(err){
  if(err){
    console.log(console.log(err));
    return console.log(err);
  }
  console.log("File test saved");
});

fs.appendFile('test', 'message to append', function(err){
  if(err) throw err;
  console.log('Appended text to file test');
});
